package pt.fct.ipm2.ui.exercises

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import pt.fct.ipm2.ExercisesRecyclerView.Exercises
import pt.fct.ipm2.ExercisesRecyclerView.ExercisesAdapter
import pt.fct.ipm2.ExercisesRecyclerView.ExercisesDB
import pt.fct.ipm2.MainActivity
import pt.fct.ipm2.R


class ExercisesFragment() :Fragment(), ExercisesAdapter.OnItemClickListener {


    private lateinit var exercisesViewModel: ExercisesViewModel
    private lateinit var recyclerViewEx: RecyclerView
    private lateinit var viewAdapterEx: RecyclerView.Adapter<*>
    private lateinit var viewManagerEx: RecyclerView.LayoutManager
    lateinit var root:View
    val args: ExercisesFragmentArgs by navArgs()

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        //exercisesCategoriesViewModel =
        //  ViewModelProvider(this).get(ExercisesCategoriesViewModel::class.java)
        exercisesViewModel =
                ViewModelProvider(this).get(ExercisesViewModel::class.java)
        root = inflater.inflate(R.layout.fragment_exercises, container, false)
        // val textView: TextView = root.findViewById(R.id.text_gallery)
        //exercisesViewModel.text.observe(viewLifecycleOwner, Observer {
        //   textView.text = it
        //})

        (activity as MainActivity).supportActionBar?.title = args.category

        var data =loadExercises(args.category)
        return root
    }

    fun loadExercises(category: String):MutableList<Exercises>{
        var exercises = mutableListOf<Exercises>()
        var db =Firebase.firestore
        val settings = FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .build()
        db.firestoreSettings = settings
        val doc = db.collection("exercises").document(category).collection("exercises")
        /*doc.addSnapshotListener{ snapshot, e->
    for (document in snapshot!!.documents){
        Log.e("Firestore", document.id)
        val exercise =Exercises(
                document.id,
                category,
                R.drawable.rodarcabeca,
                "${document.data?.get("description")}",
                "01:00"
        )
        Log.e("size", exercises.size.toString())
        exercises.add(exercise)
        Log.e("size", exercises.size.toString())
    } }
*/
        doc.get().addOnSuccessListener { documents ->
            for (document in documents) {
                val exercise =Exercises(
                        document.id,
                        category,
                        R.drawable.rodarcabeca,
                        "${document.data?.get("description")}",
                        "01:00"
                )
                exercises.add(exercise)
                viewAdapterEx.notifyItemInserted(exercises.size-1)
            }
        }
                .addOnFailureListener { exception ->
                    Log.e("FALHA", "Error getting documents: ", exception)
                }

        exercisesRecyclerView(exercises as MutableList<Exercises>)
        return exercises
    }

    fun exercisesRecyclerView(list: MutableList<Exercises>){
        viewManagerEx = LinearLayoutManager(root.context) //GridLayoutManager(, 2)//LinearLayoutManager(this)
        viewAdapterEx = ExercisesAdapter(list, this)

        recyclerViewEx = root.findViewById<RecyclerView>(R.id.Exercises).apply {
            // use this setting to improve performance if you know that changes
            // in content do not change the layout size of the RecyclerView
            setHasFixedSize(true)

            // use a linear layout manager
            layoutManager = viewManagerEx

            // specify an viewAdapter (see also next example)
            adapter = viewAdapterEx
        }

        val divider =DividerItemDecoration(context, LinearLayoutManager.VERTICAL)
        divider.setDrawable(resources.getDrawable(R.drawable.divider))
        recyclerViewEx.addItemDecoration(divider)

    }

    override fun onItemClick(exercise: Exercises) {
        val action =  ExercisesFragmentDirections.actionNavExercisesToShowExerciseFragment(exercise)
        NavHostFragment.findNavController(this).navigate(action)
    }


}