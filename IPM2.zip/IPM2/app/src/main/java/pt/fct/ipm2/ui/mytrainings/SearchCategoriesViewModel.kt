package pt.fct.ipm2.ui.mytrainings

import androidx.lifecycle.ViewModel

class SearchCategoriesViewModel: ViewModel() {
}