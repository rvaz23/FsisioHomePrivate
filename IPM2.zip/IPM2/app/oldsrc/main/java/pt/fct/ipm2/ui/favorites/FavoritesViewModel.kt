package pt.fct.ipm2.ui.favorites

import androidx.lifecycle.ViewModel

class FavoritesViewModel : ViewModel() {






}