package pt.fct.ipm2.ui.home


import androidx.lifecycle.ViewModel


class ShowExerciseViewModel : ViewModel() {






}