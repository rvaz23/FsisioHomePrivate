package pt.fct.ipm2.ExercisesRecyclerView

data class RecyclerViewItem(val title:String)

