package pt.fct.ipm2.ui.trainings

import androidx.lifecycle.ViewModel

class TrainingExercisesViewModel: ViewModel() {
}